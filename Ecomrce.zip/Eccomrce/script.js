var menuIcon = document.querySelector("#menuIcon");
var menu = document.querySelector("#menuItems");
menu.style.maxHeight = "0px";
menuIcon.onclick = function()
{
    if(menu.style.maxHeight == "0px"){
        menu.style.maxHeight = "200px";
    }else{
        menu.style.maxHeight = "0px";

    }

}
